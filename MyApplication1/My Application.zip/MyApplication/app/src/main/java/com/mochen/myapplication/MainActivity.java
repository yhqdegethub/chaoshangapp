package com.mochen.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e;
    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zuce);

        //初始化控件
        e=findViewById(R.id.number_1);
        bt=findViewById(R.id.button_1);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //获取文本框中的数据
                String s=e.getText().toString();
                //弹出一个消息框
                Toast.makeText(getApplicationContext(), s+"欢迎您!", Toast.LENGTH_SHORT).show();
            }
        });

    }
}